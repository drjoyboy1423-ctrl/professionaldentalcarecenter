# Professional Dental Care Center (SmartDent)

Static web app (no build step) with a shared Supabase backend, so accounts, passwords and patient records
are the same on every device.

## Files
`index.html`, `assets/cal.js` (Ethiopian calendar, payment methods), `assets/db.js` (Supabase connection), `assets/app.js`, `assets/tools.js`, `assets/theme.css`,
`favicon.svg`, `netlify.toml`, `robots.txt`.

## Deploy to Netlify
1. Drag this folder onto https://app.netlify.com/drop, or push it to Git (no build command, publish directory `.`),
   or run `netlify deploy --prod --dir=.`
2. Open the site and sign in with the admin account you were given. Change that password under Profile.

## Roles
- **Admin**: all clinics, users, clinics, analytics, invoices, printing. Cannot add patients.
- **Manager / Reception**: add patients, book appointments, invoices, analytics, print center.
- **Doctor / Nurse**: records and queue; cannot add patients.
These rules are enforced in the database (row-level security), not only in the page.

## Backend (Supabase)
Tables: `clinics`, `profiles`, `patients`, `clinic_lists`. Edge function `manage-users` creates, edits, resets and
deletes staff accounts. Sign-in uses `<username>@dental.app` internally. The page only contains the public
(publishable) key, which is safe to expose.
To reset a lost admin password: Supabase dashboard -> Authentication -> Users -> admin@dental.app.

## Ethiopian calendar
The **Calendar** button in the top bar cycles Ethiopian (EC), Gregorian (GC) and both. The choice is remembered per device.
In EC mode, date fields use Day / Month / Year pickers with Ethiopian month names, and reports and prints show EC dates.
Dates are stored as Gregorian ISO dates, so CSV exports stay Excel-friendly (the invoice CSV also has an Ethiopian date column).

## Payment methods
Cash, Telebirr, CBE Birr, CBE (bank), eBirr, Other bank and Card. Any non-cash payment needs the transaction /
reference number. Reports: Daily Payments Report, Payments by Method, and a "Payments received by method" chart in Analytics.
Payments are recorded by staff; there is no live connection to the Telebirr, CBE or eBirr systems.
